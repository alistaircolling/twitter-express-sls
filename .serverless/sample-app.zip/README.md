# Twitter API

This is an express server deployed on AWS using Serverless

## Still to do

- Add Typescript
- Tests

# Dependency choices made

- Serverless allowed me to quickly deploy to AWS
- Twit package is a wrapper for the Twitter API

## Running the Application Locally

`npm i`
`npm start`

# Deployment

`npm install -g serverless`
`sls deploy`
