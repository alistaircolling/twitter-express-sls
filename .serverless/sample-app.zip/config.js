module.exports = {
  consumer_key: "hBMv81DL5k3kWAskc5H6jg",
  consumer_secret: "MnQiXLobTXTSejYeScJPhM8e4uJy1Bg8mzgnw30BMA",
  access_token: "16739856-IO5HvFzMRGNSrmNT0Nxp5GbXJvhQeZGVeT1XEqxIi",
  access_token_secret: "rb2nYI6igVKAWX8yECndATiom1asRJKgQDt7MbBxggD72",
};
